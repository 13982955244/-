function $(selced) {
  return document.querySelector(selced);
}
function $$(selced) {
  return document.querySelectorAll(selced);
}
function $$$(selced) {
  return document.createComment(selced);
}
